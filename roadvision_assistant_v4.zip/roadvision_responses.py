def responder(assistant,pregunta,resultado):
    intent,score=assistant.predict(pregunta)
    r=resultado
    if intent=="fuera_de_dominio": return "No comprendí la consulta. Pregunta sobre los resultados de RoadVision."
    if intent=="ayuda": return "Puedes consultar cantidad y ubicación de baches, presencia y cobertura de grietas, confianza, historial, nivel de afectación, daño predominante, recomendaciones y resumen."
    if intent=="cantidad_baches" and r.get("cantidad_baches") is not None: return f"Se detectaron {r['cantidad_baches']} baches."
    if intent=="presencia_grietas" and r.get("hay_grietas") is not None: return "Se detectaron grietas." if r["hay_grietas"] else "No se detectaron grietas."
    if intent=="cobertura_grietas" and r.get("cobertura_grietas_pct") is not None: return f"La máscara cubre {r['cobertura_grietas_pct']:.2f}% de la imagen analizada."
    if intent=="confianza" and r.get("confianza_baches_promedio") is not None: return f"Confianza promedio de detecciones de baches: {100*r['confianza_baches_promedio']:.1f}%. No equivale a exactitud medida."
    if intent=="ubicacion_baches" and r.get("baches") is not None:
        if not r["baches"]: return "No se detectaron baches."
        if all(b.get("ubicacion") for b in r["baches"]): return "Ubicaciones en la imagen: "+"; ".join(str(b["ubicacion"]) for b in r["baches"])
    if intent=="nivel_afectacion" and r.get("nivel_afectacion_estimado") is not None: return f"Nivel visual estimado: {r['nivel_afectacion_estimado']}. No es una evaluación estructural."
    if intent=="dano_predominante" and r.get("dano_predominante") is not None: return f"Daño predominante según el criterio del análisis: {r['dano_predominante']}."
    if intent=="historial" and r.get("cantidad_analisis") is not None: return f"Tienes {r['cantidad_analisis']} análisis autorizados registrados."
    if intent=="recomendacion" and (r.get("cantidad_baches") or r.get("hay_grietas")): return "Se recomienda verificar los daños detectados mediante una inspección técnica antes de decidir una reparación."
    if intent=="reporte_general":
        items=[]
        if r.get("cantidad_baches") is not None: items.append(f"Baches detectados: {r['cantidad_baches']}")
        if r.get("cobertura_grietas_pct") is not None: items.append(f"Cobertura de grietas en imagen: {r['cobertura_grietas_pct']:.2f}%")
        if r.get("nivel_afectacion_estimado") is not None: items.append(f"Afectación visual estimada: {r['nivel_afectacion_estimado']}")
        if items: return "; ".join(items)+"."
    return "No hay datos suficientes para responder esta consulta en el análisis seleccionado."

