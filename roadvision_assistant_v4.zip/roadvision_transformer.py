import json, math, re, unicodedata
from pathlib import Path
import torch
from torch import nn

PAD, UNK, CLS = "<PAD>", "<UNK>", "<CLS>"

def tokens(text):
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    return re.findall(r"[a-z0-9]+", text)

def merge_pair(seq, pair):
    out=[]; i=0
    while i<len(seq):
        if i+1<len(seq) and (seq[i],seq[i+1])==pair:
            out.append(seq[i]+seq[i+1]); i+=2
        else: out.append(seq[i]); i+=1
    return tuple(out)

def fit_bpe(texts, max_merges=450, min_freq=3):
    from collections import Counter
    words=Counter(tuple("▁"+w) for text in texts for w in tokens(text))
    vocab={PAD:0,UNK:1,CLS:2}
    for c in "▁abcdefghijklmnopqrstuvwxyz0123456789": vocab[c]=len(vocab)
    merges=[]
    for _ in range(max_merges):
        pairs=Counter()
        for seq,n in words.items():
            for pair in zip(seq,seq[1:]): pairs[pair]+=n
        if not pairs: break
        pair=min(pairs,key=lambda p:(-pairs[p],p))
        if pairs[pair]<min_freq: break
        merges.append(list(pair)); new=Counter()
        for seq,n in words.items(): new[merge_pair(seq,pair)]+=n
        words=new
        joined="".join(pair)
        if joined not in vocab: vocab[joined]=len(vocab)
    return vocab,merges

def encode(text,vocab,max_len,merges):
    ranks={tuple(p):i for i,p in enumerate(merges)}
    pieces=[]
    for word in tokens(text)[:max_len]:
        seq=tuple("▁"+word[:100])
        while len(seq)>1:
            available=[p for p in zip(seq,seq[1:]) if p in ranks]
            if not available: break
            pair=min(available,key=ranks.__getitem__)
            seq=merge_pair(seq,pair)
        pieces.extend(seq)
        if len(pieces)>=max_len-1: break
    ids=[vocab[CLS]]+[vocab.get(t,vocab[UNK]) for t in pieces[:max_len-1]]
    return ids+[vocab[PAD]]*(max_len-len(ids))

class SelfAttention(nn.Module):
    def __init__(self, dim, heads, dropout):
        super().__init__()
        assert dim % heads == 0
        self.heads, self.dk = heads, dim // heads
        self.q = nn.Linear(dim, dim)
        self.k = nn.Linear(dim, dim)
        self.v = nn.Linear(dim, dim)
        self.out = nn.Linear(dim, dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x, valid):
        b, t, d = x.shape
        def split(z): return z.reshape(b,t,self.heads,self.dk).transpose(1,2)
        q,k,v = split(self.q(x)), split(self.k(x)), split(self.v(x))
        scores = (q @ k.transpose(-2,-1)) / math.sqrt(self.dk)
        scores = scores.masked_fill(~valid[:,None,None,:], float("-inf"))
        weights = self.drop(scores.softmax(dim=-1))
        context = (weights @ v).transpose(1,2).contiguous().reshape(b,t,d)
        return self.out(context)

class EncoderBlock(nn.Module):
    def __init__(self, dim, heads, ff_dim, dropout):
        super().__init__()
        self.attn = SelfAttention(dim, heads, dropout)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(nn.Linear(dim,ff_dim),nn.GELU(),nn.Dropout(dropout),nn.Linear(ff_dim,dim))
        self.drop = nn.Dropout(dropout)

    def forward(self, x, valid):
        x = self.norm1(x + self.drop(self.attn(x,valid)))
        return self.norm2(x + self.drop(self.ff(x)))

class RoadVisionTransformer(nn.Module):
    def __init__(self, vocab_size, num_classes, max_len=48, dim=96, heads=4, ff_dim=192, layers=2, dropout=0.30):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size,dim,padding_idx=0)
        self.position = nn.Embedding(max_len,dim)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList([EncoderBlock(dim,heads,ff_dim,dropout) for _ in range(layers)])
        self.intent = nn.Linear(dim,num_classes)  # 11 intenciones válidas
        self.domain = nn.Linear(dim,2)  # 0: fuera, 1: dentro
        self.projection = nn.Sequential(nn.Linear(dim,dim),nn.GELU(),nn.Linear(dim,64))

    def forward(self, ids):
        valid=ids.ne(0)
        pos=torch.arange(ids.size(1),device=ids.device)
        x=self.drop(self.embedding(ids)+self.position(pos)[None,:,:])
        for block in self.blocks: x=block(x,valid)
        pooled=(x*valid.unsqueeze(-1)).sum(1)/valid.sum(1,keepdim=True).clamp_min(1)
        h=0.5*(x[:,0]+pooled)
        return self.intent(h),self.domain(h),nn.functional.normalize(self.projection(h),dim=-1)

def decide(intent_logits,domain_logits,meta,reject=True):
    p=(intent_logits/meta["intent_temperature"]).softmax(-1)
    d=(domain_logits/meta["domain_temperature"]).softmax(-1)
    ids=torch.tensor(meta["intent_ids"],device=p.device)
    top,idx=p.topk(2,dim=-1)
    # Probabilidades conjuntas P(intención|dominio)*P(dominio).
    joint=p*d[:,1,None]
    raw=torch.cat([joint,d[:,0,None]],dim=1).argmax(-1)
    lookup=torch.cat([ids,ids.new_tensor([meta["ood"]])])
    pred=lookup[raw]
    if reject:
        bad=(d[:,1]<meta["domain_threshold"])|(top[:,0]<meta["intent_threshold"])|((top[:,0]-top[:,1])<meta["margin"])
        pred=pred.masked_fill(bad,meta["ood"])
    score=torch.where(pred.eq(meta["ood"]),d[:,0],joint.max(-1).values)
    return pred,score

class Assistant:
    def __init__(self,folder,device="cpu"):
        folder=Path(folder)
        self.meta=json.loads((folder/"config.json").read_text(encoding="utf-8"))
        if self.meta["version"]!=4: raise ValueError("Se requieren archivos V4")
        self.labels=self.meta["labels"]; self.device=torch.device(device)
        self.model=RoadVisionTransformer(**self.meta["model"]).to(self.device)
        self.model.load_state_dict(torch.load(folder/"transformer_best.pt",map_location=self.device,weights_only=True))
        self.model.eval()
    @torch.inference_mode()
    def predict(self,text):
        if not tokens(text): return "fuera_de_dominio",0.0
        ids=torch.tensor([encode(text,self.meta["vocab"],self.meta["model"]["max_len"],self.meta["merges"])],device=self.device)
        i,d,_=self.model(ids)
        pred,score=decide(i,d,self.meta)
        return self.labels[int(pred[0])],float(score[0])
