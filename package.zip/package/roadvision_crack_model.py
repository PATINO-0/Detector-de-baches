"""U-Net pequeña para segmentación binaria de grietas en imágenes RGB.

Cada salida representa la probabilidad de grieta de un píxel. Se conservan
conexiones entre encoder y decoder para recuperar bordes y estructuras finas.
Las capas tienen equivalentes directos en Keras para exportar los mismos pesos.
"""

import torch
from torch import nn
from torch.nn import functional as F


class ConvBlock(nn.Module):
    """Dos convoluciones de 3×3 con relleno que conserva alto y ancho."""

    def __init__(self, input_channels, output_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(input_channels, output_channels, 3, padding=1)
        self.conv2 = nn.Conv2d(output_channels, output_channels, 3, padding=1)

    def forward(self, x):
        return F.relu(self.conv2(F.relu(self.conv1(x))))


class CrackUNet(nn.Module):
    """Tres reducciones espaciales y tres reconstrucciones con conexiones U-Net.

    La entrada utiliza NCHW, RGB y valores entre cero y uno. La salida contiene
    logits N×1×H×W. Aplicar sigmoid permite convertirlos en probabilidades.
    Alto y ancho deben ser múltiplos de ocho.
    """

    def __init__(self, width=16):
        super().__init__()
        self.width = width
        self.enc1 = ConvBlock(3, width)
        self.enc2 = ConvBlock(width, width * 2)
        self.enc3 = ConvBlock(width * 2, width * 4)
        self.bridge = ConvBlock(width * 4, width * 8)
        self.dec3 = ConvBlock(width * 12, width * 4)
        self.dec2 = ConvBlock(width * 6, width * 2)
        self.dec1 = ConvBlock(width * 3, width)
        self.head = nn.Conv2d(width, 1, 1)

    def forward(self, x):
        a = self.enc1(x)
        b = self.enc2(F.max_pool2d(a, 2))
        c = self.enc3(F.max_pool2d(b, 2))
        x = self.bridge(F.max_pool2d(c, 2))
        x = self.dec3(torch.cat((F.interpolate(x, scale_factor=2, mode="nearest"), c), dim=1))
        x = self.dec2(torch.cat((F.interpolate(x, scale_factor=2, mode="nearest"), b), dim=1))
        x = self.dec1(torch.cat((F.interpolate(x, scale_factor=2, mode="nearest"), a), dim=1))
        return self.head(x)


def keras_equivalent(model, image_size):
    """Construir un grafo Keras y copiar cada kernel entrenado sin alterar valores.

    PyTorch guarda kernels como [salida, entrada, alto, ancho]. Keras los guarda
    como [alto, ancho, entrada, salida]. La transposición solo cambia su orden.
    Keras recibe NHWC, una disposición común para servidores Python y TensorFlow.
    """
    import keras

    layers = keras.layers
    inputs = layers.Input((image_size, image_size, 3), name="image_rgb")

    def block(x, name):
        source = getattr(model, name)
        for suffix in ("conv1", "conv2"):
            convolution = getattr(source, suffix)
            layer = layers.Conv2D(convolution.out_channels, 3, padding="same",
                                  activation="relu", name=f"{name}_{suffix}")
            x = layer(x)
            layer.set_weights([convolution.weight.detach().cpu().numpy().transpose(2, 3, 1, 0),
                               convolution.bias.detach().cpu().numpy()])
        return x

    a = block(inputs, "enc1")
    b = block(layers.MaxPooling2D()(a), "enc2")
    c = block(layers.MaxPooling2D()(b), "enc3")
    x = block(layers.MaxPooling2D()(c), "bridge")
    for skip, name in ((c, "dec3"), (b, "dec2"), (a, "dec1")):
        x = layers.UpSampling2D(interpolation="nearest")(x)
        x = block(layers.Concatenate()([x, skip]), name)
    head = layers.Conv2D(1, 1, name="logits")
    logits = head(x)
    head.set_weights([model.head.weight.detach().cpu().numpy().transpose(2, 3, 1, 0),
                      model.head.bias.detach().cpu().numpy()])
    return keras.Model(inputs, layers.Activation("sigmoid", name="crack_probability")(logits),
                       name="RoadVisionCrackUNet")
