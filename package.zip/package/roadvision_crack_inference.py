"""Inferencia de grietas reutilizable desde FastAPI, Flask o scripts de Python.

El predictor carga una sesión ONNX una sola vez. Cada llamada recibe una ruta
o una matriz RGB uint8 y devuelve probabilidades y máscara al tamaño original.
"""

import argparse
import hashlib
import json
import pickle
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort


def letterbox(image, size, mask=None):
    """Compartir la misma geometría entre preparación de datos e inferencia.

    La imagen usa interpolación lineal. La máscara usa vecino más cercano para
    conservar las etiquetas. La geometría permite retirar el relleno después.
    """
    height, width = image.shape[:2]
    scale = size / max(height, width)
    resized_width, resized_height = max(1, round(width * scale)), max(1, round(height * scale))
    left, top = (size - resized_width) // 2, (size - resized_height) // 2
    canvas = np.full((size, size, 3), 114, dtype=np.uint8)
    canvas[top:top + resized_height, left:left + resized_width] = cv2.resize(
        image, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR)
    geometry = {"left": left, "top": top, "width": resized_width, "height": resized_height,
                "original_width": width, "original_height": height}
    target = None
    if mask is not None:
        target = np.zeros((size, size), dtype=np.uint8)
        target[top:top + resized_height, left:left + resized_width] = cv2.resize(
            mask, (resized_width, resized_height), interpolation=cv2.INTER_NEAREST)
    return canvas, target, geometry


class CrackPredictor:
    """Cargar un ONNX con JSON contiguo o un PKL propio con grafo y metadatos.

    Pickle ejecuta objetos al cargarlos. Utilizar solamente el paquete generado
    por este proyecto y conservar su procedencia.
    """

    def __init__(self, model_path, threads=4):
        model_path = Path(model_path)
        if model_path.suffix.lower() == ".pkl":
            with model_path.open("rb") as stream:
                payload = pickle.load(stream)
            self.metadata, graph = payload["metadata"], payload["onnx_bytes"]
        else:
            self.metadata = json.loads(model_path.with_suffix(".json").read_text(encoding="utf-8"))
            graph = model_path.read_bytes()
        if hashlib.sha256(graph).hexdigest() != self.metadata["onnx_sha256"]:
            raise ValueError("El SHA-256 del modelo no coincide con sus metadatos.")
        options = ort.SessionOptions()
        options.intra_op_num_threads = threads
        self.session = ort.InferenceSession(graph, sess_options=options, providers=["CPUExecutionProvider"])

    def predict(self, source, threshold=None):
        """Devolver mapa de probabilidades, máscara 0/255 y proporción de grieta.

        El umbral es una probabilidad entre cero y uno. El valor predeterminado
        procede de validación. La proporción mide área visible en la imagen.
        """
        if isinstance(source, (str, Path)):
            bgr = cv2.imread(str(source))
            if bgr is None:
                raise ValueError(f"No se pudo leer la imagen {source}")
            image = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        else:
            image = np.asarray(source)
        if image.ndim != 3 or image.shape[2] != 3 or image.dtype != np.uint8 or not image.size:
            raise ValueError("La imagen debe ser RGB uint8, con forma alto×ancho×3.")
        threshold = self.metadata["threshold"] if threshold is None else float(threshold)
        if not np.isfinite(threshold) or not 0 <= threshold <= 1:
            raise ValueError("El umbral debe estar entre cero y uno.")
        size = self.metadata["image_size"]
        height, width = image.shape[:2]
        canvas, _, geometry = letterbox(image, size)
        top, left = geometry["top"], geometry["left"]
        inputs = np.ascontiguousarray(canvas.transpose(2, 0, 1)[None], dtype=np.float32) / 255
        probabilities = self.session.run(["probabilities"], {"images": inputs})[0][0, 0]
        probabilities = probabilities[top:top + geometry["height"], left:left + geometry["width"]]
        probabilities = cv2.resize(probabilities, (width, height), interpolation=cv2.INTER_LINEAR)
        mask = (probabilities >= threshold).astype(np.uint8) * 255
        return {"probabilities": probabilities, "mask": mask,
                "crack_fraction": float(np.count_nonzero(mask) / mask.size), "threshold": threshold}

    def save(self, source, output):
        """Guardar una máscara PNG y una superposición roja sobre la imagen."""
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)
        result = self.predict(source)
        image = cv2.imread(str(source))
        overlay = image.copy()
        positive = result["mask"] > 0
        overlay[positive] = (0.55 * image[positive] + 0.45 * np.array([0, 0, 255])).astype(np.uint8)
        if not cv2.imwrite(str(output.with_name(output.name + "_mask.png")), result["mask"]):
            raise OSError("No se pudo guardar la máscara.")
        if not cv2.imwrite(str(output.with_name(output.name + "_overlay.png")), overlay):
            raise OSError("No se pudo guardar la superposición.")
        return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("grietas_resultado"))
    args = parser.parse_args()
    result = CrackPredictor(args.model).save(args.image, args.output)
    print(json.dumps({"crack_fraction": result["crack_fraction"], "threshold": result["threshold"]}))
