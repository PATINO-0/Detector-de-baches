"""Entrenar, evaluar y empaquetar el segmentador de grietas de RoadVisionAI.

Uso desde la raíz del proyecto con el intérprete .venv-cuda:
    python -m roadvision_cracks all --epochs 50
    python -m roadvision_cracks train --epochs 50 --resume
    python -m roadvision_cracks package
"""

import argparse
import hashlib
import json
import os
import pickle
import shutil
import time
from pathlib import Path

import numpy as np
import torch
from filelock import FileLock
from torch.nn import functional as F
from torch.utils.data import DataLoader

from roadvision_crack_data import ROOT, CrackDataset, prepare, write_json
from roadvision_crack_model import CrackUNet, keras_equivalent


def save_checkpoint(path, payload):
    """Reemplazar el checkpoint solamente después de escribir todos sus bytes."""
    temporary = path.with_suffix(".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def pixel_metrics(tp, fp, fn, tn):
    """Métricas de píxeles de grieta. El fondo queda fuera del F1 y del IoU."""
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    return {"precision": precision, "recall": recall,
            "F1_Dice": 2 * tp / max(2 * tp + fp + fn, 1),
            "IoU": tp / max(tp + fp + fn, 1),
            "tp_pixels": tp, "fp_pixels": fp, "fn_pixels": fn, "tn_pixels": tn}


@torch.inference_mode()
def evaluate(model, loader, device, thresholds):
    """Medir cada umbral en píxeles válidos, excluyendo el relleno del letterbox.

    La agregación es global sobre todos los píxeles de la división. La selección
    de umbral usa val. Test se consulta con el umbral ya fijado.
    """
    model.eval()
    counts = np.zeros((len(thresholds), 4), dtype=np.int64)
    for images, truth, valid in loader:
        images = images.to(device, non_blocking=True)
        probabilities = model(images).sigmoid().float()
        truth, valid = truth.to(device).bool(), valid.to(device).bool()
        positive = truth & valid
        negative = ~truth & valid
        for index, threshold in enumerate(thresholds):
            predicted = probabilities >= threshold
            values = torch.stack(((predicted & positive).sum(), (predicted & negative).sum(),
                                  (~predicted & positive).sum(), (~predicted & negative).sum()))
            counts[index] += values.cpu().numpy()
    return [{"threshold": float(threshold), **pixel_metrics(*map(int, row))}
            for threshold, row in zip(thresholds, counts)]


def train(manifest, args):
    """Ajustar U-Net desde cero y elegir pesos por Dice de validación a umbral 0,5.

    Se guarda el estado completo de AdamW, scheduler, AMP y generadores aleatorios
    para continuar la misma corrida. El mejor checkpoint se conserva aparte.
    """
    output = ROOT / "training"
    output.mkdir(parents=True, exist_ok=True)
    if (output / "last.pt").is_file() and not args.resume:
        raise FileExistsError("Ya existe una corrida. Utiliza --resume para continuarla.")
    torch.manual_seed(42)
    np.random.seed(42)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = True
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    config = {"image_size": args.imgsz, "width": 16, "epochs": args.epochs,
              "batch": args.batch, "manifest": str(manifest), "seed": 42,
              "learning_rate": 0.001, "patience": 10, "trained_from_scratch": True}
    train_data = CrackDataset(manifest, "train", augment=True)
    valid_data = CrackDataset(manifest, "val")
    loader = DataLoader(train_data, batch_size=args.batch, shuffle=True, num_workers=0,
                        pin_memory=device.type == "cuda")
    validation = DataLoader(valid_data, batch_size=args.batch, num_workers=0,
                            pin_memory=device.type == "cuda")
    data_report = json.loads(Path(manifest).read_text(encoding="utf-8"))
    statistics = data_report["splits"]["train"]
    ratio = (statistics["valid_pixels"] - statistics["foreground_pixels"]) / max(statistics["foreground_pixels"], 1)
    positive_weight = min(max(ratio, 1.0), 15.0)
    model = CrackUNet(config["width"]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["learning_rate"], weight_decay=0.0001)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, args.epochs, eta_min=0.00001)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    start, best, best_epoch, history = 0, -1.0, 0, []
    if args.resume:
        state = torch.load(output / "last.pt", map_location="cpu", weights_only=True)
        if state["config"] != config:
            raise ValueError("La configuración debe coincidir con la corrida que se reanuda.")
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        scaler.load_state_dict(state["scaler"])
        torch.set_rng_state(state["torch_rng"])
        if device.type == "cuda":
            torch.cuda.set_rng_state_all(state["cuda_rng"])
        start, best, best_epoch, history = state["epoch"], state["best"], state["best_epoch"], state["history"]
    weight = torch.tensor(positive_weight, device=device)
    print(f"Entrenamiento en {device} | {sum(p.numel() for p in model.parameters()):,} parámetros | peso positivo {positive_weight:.2f}", flush=True)
    for epoch in range(start + 1, args.epochs + 1):
        if epoch - best_epoch > config["patience"]:
            break
        began = time.monotonic()
        model.train()
        accumulated = torch.zeros((), device=device)
        for images, targets, valid in loader:
            images, targets, valid = (x.to(device, non_blocking=True) for x in (images, targets, valid))
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=device.type == "cuda"):
                logits = model(images)
                bce = F.binary_cross_entropy_with_logits(logits, targets, pos_weight=weight, reduction="none")
                bce = (bce * valid).sum() / valid.sum().clamp_min(1)
                probabilities = logits.sigmoid().float() * valid
                # Dice se calcula en FP32 para evitar overflow al sumar máscaras.
                intersection = (probabilities * targets).sum(dim=(1, 2, 3))
                denominator = probabilities.sum(dim=(1, 2, 3)) + (targets * valid).sum(dim=(1, 2, 3))
                dice_loss = 1 - ((2 * intersection + 1) / (denominator + 1)).mean()
                loss = bce + dice_loss
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            accumulated += loss.detach() * len(images)
        scheduler.step()
        metrics = evaluate(model, validation, device, [0.5])[0]
        row = {"epoch": epoch, "loss": float(accumulated) / len(train_data),
               "seconds": time.monotonic() - began, "validation": metrics}
        history.append(row)
        if metrics["F1_Dice"] > best:
            best, best_epoch = metrics["F1_Dice"], epoch
            save_checkpoint(output / "best.pt", {"model": model.state_dict(), "config": config,
                                                "epoch": epoch, "validation": metrics})
        save_checkpoint(output / "last.pt", {"model": model.state_dict(), "config": config,
                        "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                        "scaler": scaler.state_dict(), "epoch": epoch, "best": best,
                        "best_epoch": best_epoch, "history": history, "torch_rng": torch.get_rng_state(),
                        "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else []})
        write_json(output / "history.json", {"config": config, "positive_weight": positive_weight,
                                             "best_epoch": best_epoch, "history": history})
        print(f"Época {epoch}/{args.epochs} | pérdida {row['loss']:.4f} | Dice {metrics['F1_Dice']:.2%} | IoU {metrics['IoU']:.2%} | {row['seconds']:.1f}s", flush=True)
    return output / "best.pt"


def package(checkpoint):
    """Calibrar, evaluar test y verificar exportaciones con imágenes reales.

    Keras contiene un grafo funcional y los mismos pesos del checkpoint ganador.
    PKL contiene los bytes ONNX y el contrato. Se comprueba que ambos producen
    probabilidades equivalentes a PyTorch antes de publicar el informe final.
    """
    os.environ["KERAS_BACKEND"] = "torch"
    import keras
    import onnx
    import onnxruntime as ort

    torch.set_num_threads(4)
    # Evaluar/exportar en FP32 evita diferencias de TF32 entre CPU y GPU.
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    config = state["config"]
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = CrackUNet(config["width"]).to(device)
    model.load_state_dict(state["model"])
    model.eval()
    manifest = Path(config["manifest"])
    validation = DataLoader(CrackDataset(manifest, "val"), batch_size=config["batch"])
    curves = evaluate(model, validation, device, np.linspace(0.05, 0.95, 37))
    selected = max(curves, key=lambda row: row["F1_Dice"])
    test_data = CrackDataset(manifest, "test")
    test = evaluate(model, DataLoader(test_data, batch_size=config["batch"]), device, [selected["threshold"]])[0]
    output = ROOT / "package"
    output.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(checkpoint, output / "grietas.pt")
    model = model.cpu()
    wrapper = torch.nn.Sequential(model, torch.nn.Sigmoid()).eval()
    # La entrada y la salida ONNX usan NCHW y lote dinámico. La resolución es fija.
    probe = torch.stack([test_data[index][0] for index in range(min(4, len(test_data)))])
    with torch.inference_mode():
        expected = wrapper(probe).numpy()
    torch.onnx.export(wrapper, probe[:1], str(output / "grietas.onnx"), opset_version=17,
                      input_names=["images"], output_names=["probabilities"],
                      dynamic_axes={"images": {0: "batch"}, "probabilities": {0: "batch"}}, dynamo=False)
    onnx.checker.check_model(str(output / "grietas.onnx"))
    session_options = ort.SessionOptions()
    session_options.intra_op_num_threads = 4
    graph = (output / "grietas.onnx").read_bytes()
    session = ort.InferenceSession(graph, sess_options=session_options, providers=["CPUExecutionProvider"])
    actual = session.run(None, {"images": probe.numpy()})[0]
    np.testing.assert_allclose(actual, expected, rtol=0.001, atol=0.0001)
    # Keras selecciona GPU automáticamente. Fijar CPU permite comparar todos
    # los formatos con la misma aritmética y los mismos cuatro fotogramas.
    with keras.device("cpu"):
        keras_model = keras_equivalent(model, config["image_size"])
        keras_model.save(output / "grietas.keras")
        keras_model.save_weights(output / "grietas.weights.h5")
        loaded_keras = keras.models.load_model(output / "grietas.keras", compile=False)
        loaded_keras.load_weights(output / "grietas.weights.h5")
        with torch.inference_mode():
            keras_output = loaded_keras(probe.permute(0, 2, 3, 1), training=False).cpu().numpy().transpose(0, 3, 1, 2)
    np.testing.assert_allclose(keras_output, expected, rtol=0.001, atol=0.0001)
    data_report = json.loads(manifest.read_text(encoding="utf-8"))
    metadata = {"schema_version": 1, "task": "binary_semantic_segmentation", "labels": ["Grieta"],
                "architecture": "CrackUNet", "width": config["width"], "best_epoch": state["epoch"],
                "image_size": config["image_size"], "threshold": selected["threshold"],
                "input": {"onnx_layout": "NCHW", "keras_layout": "NHWC", "dtype": "float32",
                          "color": "RGB", "scale": 1 / 255, "letterbox_pad": 114},
                "output": "probabilidad de grieta por píxel; retirar relleno y recuperar tamaño original",
                "metrics_protocol": "píxeles válidos a resolución de entrada; agregación global; IoU y Dice de grieta",
                "dataset": {"url": data_report["source_url"], "sha256": data_report["archive_sha256"],
                            "images": {key: value["images"] for key, value in data_report["splits"].items()},
                            "includes_road_and_wall_cracks": True,
                            "excluded_duplicates": len(data_report["excluded_duplicates"])},
                "validation": selected, "test": test,
                "verification": {"real_images": len(probe),
                                 "onnx_max_absolute_error": float(np.max(np.abs(actual - expected))),
                                 "keras_max_absolute_error": float(np.max(np.abs(keras_output - expected)))},
                "onnx_sha256": hashlib.sha256(graph).hexdigest()}
    write_json(output / "grietas.json", metadata)
    with (output / "grietas.pkl").open("wb") as stream:
        pickle.dump({"metadata": metadata, "onnx_bytes": graph}, stream, protocol=pickle.HIGHEST_PROTOCOL)
    with (output / "grietas.pkl").open("rb") as stream:
        reloaded = pickle.load(stream)
    if reloaded["onnx_bytes"] != graph or reloaded["metadata"] != metadata:
        raise ValueError("El paquete PKL difiere del modelo verificado.")
    write_json(ROOT / "evaluation.json", {"validation_thresholds": curves, **metadata})
    for filename in ("roadvision_crack_inference.py", "roadvision_crack_model.py", "roadvision_crack_data.py", "roadvision_cracks.py",
                     "requirements_roadvision_grietas.txt", "README_ROADVISION_GRIETAS.md"):
        source = Path(__file__).resolve().parent / filename
        shutil.copyfile(source, output / filename)
    # El predictor también se ejecuta desde el paquete para comprobar su entrada pública.
    from roadvision_crack_inference import CrackPredictor
    predictor = CrackPredictor(output / "grietas.onnx")
    example = data_report["splits"]["test"]["entries"][0]["image"]
    predictor.save(example, output / "example")
    pkl_result = CrackPredictor(output / "grietas.pkl").predict(example)
    np.testing.assert_array_equal(predictor.predict(example)["mask"], pkl_result["mask"])
    shutil.make_archive(str(ROOT / "grietas_python"), "zip", output)
    print(json.dumps({"best_epoch": state["epoch"], "validation": selected, "test": test,
                      "verification": metadata["verification"], "package": str(output)}, indent=2), flush=True)
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", choices=("prepare", "train", "package", "all"))
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--imgsz", type=int, default=384)
    parser.add_argument("--batch", type=int, default=12)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch < 1 or args.imgsz < 32 or args.imgsz % 8:
        parser.error("Épocas y lote positivos; imgsz debe ser múltiplo de ocho y al menos 32.")
    ROOT.mkdir(parents=True, exist_ok=True)
    with FileLock(str(ROOT / "pipeline.lock"), timeout=0):
        if args.step in ("prepare", "train", "all"):
            manifest = prepare(args.imgsz)
        if args.step in ("train", "all"):
            train(manifest, args)
        if args.step in ("package", "all"):
            package(ROOT / "training" / "best.pt")


if __name__ == "__main__":
    main()
