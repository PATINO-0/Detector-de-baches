# RoadVisionAI · Segmentación de grietas para Python

El modelo U-Net produce una probabilidad de grieta por píxel y una máscara
binaria. Usa el conjunto Crack-Seg de Ultralytics, con imágenes de carreteras
y paredes. Las máscaras unen los polígonos de la clase `crack` en una clase
semántica `Grieta`.

## Datos y preparación

La descarga oficial se conserva en `RoadVisionAI_Grietas/downloads`. El código
comprueba rutas del ZIP, lectura de imágenes, presencia de etiquetas, clase,
coordenadas normalizadas y geometría de polígonos. Rasteriza los polígonos en
su resolución original y prepara entradas RGB de 384 × 384 con letterbox.

Se conservan train, val y test oficiales. Las imágenes exactamente iguales
por píxeles se deduplican, con prioridad test, después val y después train.
El manifiesto contiene SHA-256 del ZIP, imágenes, exclusiones y número de
píxeles. Las etiquetas ausentes detienen la preparación. Las etiquetas vacías
se interpretan como negativos explícitos.

## Entrenamiento

El entorno usado es Python 3.12 en Windows con PyTorch CUDA 12.8. Para preparar
otro entorno compatible se pueden ejecutar estos comandos.

```powershell
python -m pip install torch==2.11.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements_roadvision_grietas.txt
```

Se entrena desde cero una U-Net con ancho inicial de 16 canales, tres niveles
de reducción espacial y conexiones entre encoder y decoder. La pérdida suma
BCE ponderada y Dice. El peso positivo se calcula solo con train y se limita
a 15. Los aumentos de train incluyen volteos y cambios suaves de brillo.
Validación y prueba conservan sus imágenes sin aumentos.

La configuración inicial permite hasta 50 épocas, lote 12, AdamW a 0,001,
descenso coseno y parada después de 10 épocas sin mejorar. Se elige el mejor
checkpoint por Dice global de validación a umbral 0,5. Después se calibra el
umbral entre 0,05 y 0,95 únicamente en validación. Test se mide con los pesos
y umbral ya elegidos.

```powershell
.\.venv-cuda\Scripts\python.exe -m roadvision_cracks all --epochs 50
# Recuperar una corrida interrumpida con su configuración original.
.\.venv-cuda\Scripts\python.exe -m roadvision_cracks all --epochs 50 --resume
# Regenerar los formatos desde el mejor checkpoint disponible.
.\.venv-cuda\Scripts\python.exe -m roadvision_cracks package
```

`training/last.pt` permite reanudar modelo, optimizador, scheduler y AMP.
`training/best.pt` conserva los mejores pesos. `training/history.json` registra
las curvas por época. Los archivos temporales se reemplazan de forma atómica
y un bloqueo impide ejecutar dos entrenamientos sobre la misma carpeta.

## Métricas

`evaluation.json` registra precisión, recall, F1/Dice e IoU de píxeles de grieta,
con agregación global y relleno excluido. La evaluación usa máscaras a 384 px.
El mAP de cajas de los detectores de baches corresponde a una tarea diferente.
El porcentaje de área de grieta en una foto depende de la perspectiva y la
resolución. El dataset incluye paredes, por lo que la evaluación final para
carretera requiere imágenes representativas de la cámara de la aplicación.

## Primera corrida medida

La corrida inicial del 24 de noviembre de 2026 terminó tras 30 épocas por
parada temprana. Se eligieron los pesos de la época 20 y un umbral de 0,85.
Se utilizaron 3.717 imágenes de train, 200 de val y 111 imágenes únicas de
test. Una imagen repetida dentro de test se excluyó del cómputo.

| Métrica de píxeles de grieta | Validación | Prueba |
| --- | ---: | ---: |
| Precisión | 73,70 % | 71,58 % |
| Recall | 76,87 % | 73,67 % |
| F1 / Dice | 75,25 % | 72,61 % |
| IoU | 60,32 % | 57,00 % |

La diferencia máxima de probabilidades en las cuatro imágenes verificadas
fue 0,00000197 para ONNX y 0,00000233 para Keras respecto a PyTorch en CPU.
`grietas.json` conserva las cifras completas y el contrato de inferencia.

## Archivos para integración

`RoadVisionAI_Grietas/package` contiene los siguientes archivos.

| Archivo | Contenido y uso |
| --- | --- |
| `grietas.pt` | Pesos PyTorch, arquitectura configurada y época seleccionada |
| `grietas.keras` | Modelo funcional Keras completo con los mismos pesos |
| `grietas.weights.h5` | Pesos Keras para cargar sobre esa arquitectura |
| `grietas.onnx` | Grafo ONNX con salida de probabilidades |
| `grietas.pkl` | Diccionario con bytes ONNX y metadatos |
| `grietas.json` | Umbral, contrato de tensores, métricas y SHA-256 |
| `roadvision_crack_inference.py` | Predictor ONNX/PKL reutilizable en un servidor |
| `roadvision_cracks.py` y módulos auxiliares | Código comentado para reproducir el proceso |
| `example_mask.png`, `example_overlay.png` | Ejemplo de inferencia sobre test |

Las exportaciones se comparan contra PyTorch sobre cuatro imágenes reales.
Se comprueban el grafo ONNX, la recarga del archivo Keras y el contenido PKL.
La equivalencia se comprueba en CPU FP32. La evaluación final desactiva TF32
para reducir las diferencias numéricas entre ejecución en CPU y GPU.
El ZIP `RoadVisionAI_Grietas/grietas_python.zip` reúne todo el paquete.

## Uso desde una aplicación web

Copiar el contenido de `package` al servidor. Para inferencia ONNX bastan
`numpy`, `opencv-python-headless` y `onnxruntime`. Instalar las versiones
completas de `requirements_roadvision_grietas.txt` si también se entrenará
o se utilizará Keras/PyTorch.

```powershell
# Entorno de inferencia del servidor.
python -m pip install "numpy>=1.26,<3" "opencv-python-headless>=4.8,<5" onnxruntime==1.32.0
```

```python
from roadvision_crack_inference import CrackPredictor

# Crear una instancia al arrancar el servidor y reutilizarla en las peticiones.
predictor = CrackPredictor("grietas.onnx")
result = predictor.predict("foto_carretera.jpg")
mask = result["mask"]  # uint8, valores 0 o 255, al tamaño original.
probabilities = result["probabilities"]  # float32 en el intervalo [0, 1].
predictor.save("foto_carretera.jpg", "salida/carretera")
```

También se admite una matriz NumPy RGB uint8 y el archivo `grietas.pkl`.
El predictor conserva proporción, normaliza entre 0 y 1, retira el relleno
y recupera las dimensiones originales antes de aplicar el umbral. OpenCV
lee BGR y el predictor realiza la conversión a RGB al recibir una ruta.

```python
# Seleccionar el backend antes de importar Keras.
import os
os.environ["KERAS_BACKEND"] = "torch"
import keras

with keras.device("cpu"):
    model = keras.models.load_model("grietas.keras", compile=False)
    # Ejecutar model(entrada, training=False) dentro del mismo contexto.
# Entrada Keras NHWC [N, 384, 384, 3], RGB float32 normalizado.
# Aplicar el mismo letterbox que describe grietas.json.
```

```python
import torch
from roadvision_crack_model import CrackUNet

checkpoint = torch.load("grietas.pt", map_location="cpu", weights_only=True)
model = CrackUNet(width=checkpoint["config"]["width"])
model.load_state_dict(checkpoint["model"])
model.eval()
# Entrada PyTorch NCHW, mismo RGB normalizado y mismo letterbox.
# Probabilidades = torch.sigmoid(model(tensor)), dentro de torch.inference_mode().
```

```powershell
python roadvision_crack_inference.py --model grietas.onnx --image carretera.jpg --output resultados/carretera
```

## Referencias

- [Dataset Crack-Seg](https://docs.ultralytics.com/datasets/segment/crack-seg/)
- [ZIP oficial](https://github.com/ultralytics/assets/releases/download/v0.0.0/crack-seg.zip)
- [Guardar y cargar modelos Keras](https://keras.io/api/models/model_saving_apis/)

La arquitectura usa capas estándar. El archivo `.keras` contiene el grafo y
sus pesos reales. El archivo `.pkl` contiene el ONNX y su contrato para que
pueda cargarse en Python sin depender de rutas del equipo de entrenamiento.
