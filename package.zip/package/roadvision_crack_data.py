"""Descarga, comprobación y preparación de Crack-Seg para segmentación binaria."""

import hashlib
import json
import urllib.request
import zipfile
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

from roadvision_crack_inference import letterbox


URL = "https://github.com/ultralytics/assets/releases/download/v0.0.0/crack-seg.zip"
ROOT = Path(__file__).resolve().parent / "RoadVisionAI_Grietas"
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def write_json(path, payload):
    """Publicar un JSON completo mediante reemplazo atómico del temporal."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def rasterize(label, shape):
    """Unir los polígonos YOLO de clase cero en una máscara binaria.

    Un archivo vacío es un negativo explícito. Un archivo ausente se considera
    un error porque convertirlo en fondo introduciría etiquetas incorrectas.
    """
    height, width = shape[:2]
    mask = np.zeros((height, width), dtype=np.uint8)
    for line_number, line in enumerate(label.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        values = np.asarray([float(value) for value in line.split()])
        coordinates = values[1:]
        if (values[0] != 0 or len(coordinates) < 6 or len(coordinates) % 2
                or not np.isfinite(values).all() or (coordinates < 0).any() or (coordinates > 1).any()):
            raise ValueError(f"Polígono inválido en {label}, línea {line_number}.")
        points = coordinates.reshape(-1, 2) * [width - 1, height - 1]
        cv2.fillPoly(mask, [np.rint(points).astype(np.int32)], 1)
    return mask


def prepare(size):
    """Extraer el ZIP y cachear imágenes/máscaras a la resolución solicitada.

    Se conservan las divisiones oficiales. Si dos imágenes idénticas aparecen
    en divisiones distintas, se conserva test primero, luego val y finalmente
    train. El informe registra cada exclusión para poder auditar la evaluación.
    """
    archive = ROOT / "downloads" / "crack-seg.zip"
    archive.parent.mkdir(parents=True, exist_ok=True)
    if not archive.is_file():
        temporary = archive.with_suffix(".partial")
        urllib.request.urlretrieve(URL, temporary)
        temporary.replace(archive)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    cache = ROOT / f"prepared_{size}_{digest[:12]}"
    manifest = cache / "manifest.json"
    if manifest.is_file():
        return manifest
    extracted = ROOT / "source"
    extracted.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for name in zipped.namelist():
            if not (extracted / name).resolve().is_relative_to(extracted.resolve()):
                raise ValueError("El ZIP contiene una ruta fuera de la carpeta de datos.")
        zipped.extractall(extracted)
    candidates = list(extracted.rglob("images/train"))
    if len(candidates) != 1:
        raise ValueError(f"Se esperaba una raíz Crack-Seg, se encontraron {len(candidates)}.")
    source = candidates[0].parent.parent
    cache.mkdir(parents=True, exist_ok=True)
    report = {"source_url": URL, "archive_sha256": digest, "image_size": size,
              "task": "binary_semantic_segmentation", "classes": ["Grieta"],
              "includes_road_and_wall_cracks": True, "splits": {}, "excluded_duplicates": []}
    seen = {}
    for split in ("test", "val", "train"):
        rows = []
        for path in sorted((source / "images" / split).iterdir()):
            if path.suffix.lower() not in IMAGE_EXTENSIONS:
                continue
            bgr = cv2.imread(str(path))
            if bgr is None:
                raise ValueError(f"Imagen ilegible: {path}")
            image = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            image_digest = hashlib.sha256(str(image.shape).encode() + image.tobytes()).hexdigest()
            if image_digest in seen:
                report["excluded_duplicates"].append({"excluded": str(path), "kept": seen[image_digest]})
                continue
            seen[image_digest] = str(path)
            label = source / "labels" / split / f"{path.stem}.txt"
            if not label.is_file():
                raise FileNotFoundError(label)
            mask = rasterize(label, image.shape)
            rows.append((path, image, mask, image_digest))
        if not rows:
            raise ValueError(f"División vacía: {split}")
        count = len(rows)
        images = np.lib.format.open_memmap(cache / f"{split}_images.npy", mode="w+", dtype=np.uint8,
                                          shape=(count, size, size, 3))
        masks = np.lib.format.open_memmap(cache / f"{split}_masks.npy", mode="w+", dtype=np.uint8,
                                         shape=(count, size, size))
        valid = np.lib.format.open_memmap(cache / f"{split}_valid.npy", mode="w+", dtype=np.uint8,
                                         shape=(count, size, size))
        entries = []
        for index, (path, image, mask, image_digest) in enumerate(rows):
            images[index], masks[index], geometry = letterbox(image, size, mask)
            valid[index] = 0
            top, left = geometry["top"], geometry["left"]
            valid[index, top:top + geometry["height"], left:left + geometry["width"]] = 1
            entries.append({"image": str(path), "sha256_rgb": image_digest, **geometry})
        images.flush()
        masks.flush()
        valid.flush()
        report["splits"][split] = {"images": count, "foreground_pixels": int(masks.sum()),
                                    "valid_pixels": int(valid.sum()), "entries": entries}
        print(f"Datos {split}: {count} imágenes, {int(masks.sum())} píxeles de grieta.", flush=True)
    write_json(manifest, report)
    return manifest


class CrackDataset(Dataset):
    """Leer la caché y aplicar aumentos únicamente a las muestras de train."""

    def __init__(self, manifest, split, augment=False):
        folder = Path(manifest).parent
        self.images = np.load(folder / f"{split}_images.npy", mmap_mode="r")
        self.masks = np.load(folder / f"{split}_masks.npy", mmap_mode="r")
        self.valid = np.load(folder / f"{split}_valid.npy", mmap_mode="r")
        self.augment = augment

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        image, mask, valid = self.images[index], self.masks[index], self.valid[index]
        if self.augment:
            # Los mismos volteos se aplican a imagen, máscara y zona válida.
            if torch.rand(()) < 0.5:
                image, mask, valid = image[:, ::-1], mask[:, ::-1], valid[:, ::-1]
            if torch.rand(()) < 0.25:
                image, mask, valid = image[::-1], mask[::-1], valid[::-1]
        x = torch.from_numpy(np.array(image.transpose(2, 0, 1), copy=True)).float().div_(255)
        if self.augment:
            x = (x * float(torch.empty(()).uniform_(0.85, 1.15))).clamp_(0, 1)
        return x, torch.from_numpy(np.array(mask[None], copy=True)).float(), torch.from_numpy(
            np.array(valid[None], copy=True)).float()
